# Sandev Chat — Android Alpha 0.2

Sandev Chat is an Android local AI companion prototype. It uses a native Android shell and a local WebView interface, with `llama.cpp` integrated through JNI to run GGUF models on-device.

## Included in this alpha
- Local GGUF model picker using Android's system document picker.
- Native `llama.cpp` model loading and token generation (ARM64 Android builds).
- Qwen-style chat template for the intended Qwen2.5 GGUF test model.
- Character Studio: name, fictional age, relationship, detailed profile, prompt, example dialogue and profile photo.
- Per-character chat history stored locally.
- Prompt Builder with long/balanced/short style and editable global prompt.
- Auto and manual settings for context, output tokens, temperature, top-p and repeat penalty.
- Random Android notifications, configurable daily frequency and time window; schedules are restored after reboot.
- GitHub Actions workflow to build a debug APK and upload it as an artifact.

## Important notes
- This is an early alpha. It has not been built or device-tested in this workspace because the Android SDK/NDK and network access to fetch `llama.cpp` are unavailable here. The first GitHub Actions build is the compile check; fix any upstream API/build errors reported there before treating the APK as ready.
- The workflow fetches `llama.cpp` tag `b4514` during CMake configuration, so the build runner needs network access.
- First model load can take time. The model is loaded from the selected document file using an Android file descriptor; model providers that do not expose a seekable local file may fail. A local file in Downloads is recommended.
- The selected context is clamped to 256–4096 tokens. A larger context increases RAM use. On a 6 GB phone, start at 1024; the user's Qwen2.5 0.5B F16 model may still use additional RAM beyond its on-disk size.
- Current prompt formatting is Qwen2.5 ChatML-style. Other model families may need their own chat template.
- Auto mode is a conservative default, not a hardware benchmark. Output length and quality depend on the model.
- Android can delay notifications due to battery optimization. AI-generated notifications while the app is closed are not implemented; notifications use user text or local canned messages.
- The app keeps characters, chat history and settings in local WebView storage. Do not store sensitive secrets in character prompts.

## Build APK
Use GitHub Actions: push the project to a repository, open **Actions → Build Sandev Chat APK → Run workflow**. The workflow installs Android SDK platform 35, NDK 27.2, CMake 3.22.1 and Gradle 8.9, then runs `assembleDebug`. Download the `sandev-chat-debug-apk` artifact from the completed workflow.

Local build requirements: JDK 17, Android SDK platform 35, NDK 27.2.12479018, CMake 3.22.1 and Gradle 8.9.

```bash
gradle --no-daemon assembleDebug
```

APK output: `app/build/outputs/apk/debug/app-debug.apk`.
