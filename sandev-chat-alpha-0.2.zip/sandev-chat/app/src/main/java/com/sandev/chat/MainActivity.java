package com.sandev.chat;

import android.Manifest;
import android.app.Activity;
import android.app.AlarmManager;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.OpenableColumns;
import android.database.Cursor;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import android.app.AlertDialog;
import android.os.ParcelFileDescriptor;
import java.io.FileNotFoundException;
import java.io.IOException;

import java.util.Calendar;
import java.util.Random;

public class MainActivity extends Activity {
    private WebView webView;
    private ValueCallback<Uri[]> fileCallback;
    private static final int FILE_PICK = 4102;
    private static final int NOTIF_PERMISSION = 4103;
    private static final int MODEL_PICK = 4104;
    private int requestedContextLength = 1024;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        createChannel();
        webView = new WebView(this);
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = callback;
                Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("*/*");
                i.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"application/octet-stream", "application/x-gguf", "image/*"});
                startActivityForResult(i, FILE_PICK);
                return true;
            }
        });
        webView.addJavascriptInterface(new Bridge(), "Sandev");
        setContentView(webView);
        webView.loadUrl("file:///android_asset/index.html");
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, NOTIF_PERMISSION);
        }
    }


    private void loadSelectedModel(Uri uri, int contextLength) {
        runOnUiThread(() -> webView.evaluateJavascript("window.onModelLoading && window.onModelLoading()", null));
        new Thread(() -> {
            try (ParcelFileDescriptor pfd = getContentResolver().openFileDescriptor(uri, "r")) {
                if (pfd == null) throw new IOException("Tidak bisa membuka file model.");
                String path = "/proc/self/fd/" + pfd.getFd();
                boolean ok = NativeLlama.loadModel(path, Math.max(256, Math.min(4096, contextLength)), Math.max(2, Math.min(4, Runtime.getRuntime().availableProcessors() - 1)));
                if (!ok) throw new IOException("llama.cpp tidak berhasil memuat model. Coba model GGUF lain atau tutup aplikasi lain.");
                String name = queryDisplayName(uri);
                runOnUiThread(() -> webView.evaluateJavascript("window.onModelLoaded(" + org.json.JSONObject.quote(name) + ")", null));
            } catch (Throwable e) {
                String msg = e.getMessage() == null ? "Gagal memuat model." : e.getMessage();
                runOnUiThread(() -> webView.evaluateJavascript("window.onModelLoadError(" + org.json.JSONObject.quote(msg) + ")", null));
            }
        }, "sandev-model-loader").start();
    }

    private String queryDisplayName(Uri uri) {
        try (Cursor c = getContentResolver().query(uri, null, null, null, null)) {
            if (c != null && c.moveToFirst()) {
                int i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (i >= 0) return c.getString(i);
            }
        } catch (Exception ignored) { }
        return "model.gguf";
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel c = new NotificationChannel("sandev_companion", "Pesan Sandev Chat", NotificationManager.IMPORTANCE_DEFAULT);
            c.setDescription("Pesan pengingat dari karakter AI lokal");
            getSystemService(NotificationManager.class).createNotificationChannel(c);
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == FILE_PICK && fileCallback != null) {
            Uri[] result = (resultCode == RESULT_OK && data != null && data.getData() != null) ? new Uri[]{data.getData()} : null;
            fileCallback.onReceiveValue(result);
            fileCallback = null;
        } else if (requestCode == MODEL_PICK && resultCode == RESULT_OK && data != null && data.getData() != null) {
            loadSelectedModel(data.getData(), requestedContextLength);
        }
    }

    public class Bridge {
        @JavascriptInterface public void toast(String msg) { runOnUiThread(() -> Toast.makeText(MainActivity.this, msg, Toast.LENGTH_SHORT).show()); }
        @JavascriptInterface public void chooseFile() { runOnUiThread(() -> {
            Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT); i.addCategory(Intent.CATEGORY_OPENABLE); i.setType("*/*");
            i.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"application/octet-stream", "application/x-gguf", "image/*"}); startActivityForResult(i, FILE_PICK);
        }); }
        @JavascriptInterface public void chooseModel(int contextLength) { runOnUiThread(() -> {
            requestedContextLength = Math.max(256, Math.min(4096, contextLength));
            Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT); i.addCategory(Intent.CATEGORY_OPENABLE); i.setType("*/*");
            i.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"application/octet-stream", "application/x-gguf"});
            startActivityForResult(i, MODEL_PICK);
        }); }
        @JavascriptInterface public boolean isModelLoaded() { return NativeLlama.isLoaded(); }
        @JavascriptInterface public void generate(String prompt, int maxTokens, double temperature, double topP, double repeatPenalty) {
            new Thread(() -> {
                try {
                    String answer = NativeLlama.generate(prompt, maxTokens, (float) temperature, (float) topP, (float) repeatPenalty);
                    runOnUiThread(() -> webView.evaluateJavascript("window.onAIReply(" + org.json.JSONObject.quote(answer) + ")", null));
                } catch (Throwable e) {
                    String msg = e.getMessage() == null ? "Gagal menghasilkan jawaban" : e.getMessage();
                    runOnUiThread(() -> webView.evaluateJavascript("window.onAIError(" + org.json.JSONObject.quote(msg) + ")", null));
                }
            }, "sandev-inference").start();
        }
        @JavascriptInterface public void scheduleRandom(String title, String body, int minHour, int maxHour, int count) {
            if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                runOnUiThread(() -> requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, NOTIF_PERMISSION));
                return;
            }
            getSharedPreferences("sandev", MODE_PRIVATE).edit().putString("notif_title", title).putString("notif_body", body).putInt("notif_min", minHour).putInt("notif_max", maxHour).putInt("notif_count", Math.max(1, Math.min(5, count))).apply();
            scheduleNext();
            runOnUiThread(() -> Toast.makeText(MainActivity.this, "Jadwal notifikasi acak diaktifkan", Toast.LENGTH_SHORT).show());
        }
        @JavascriptInterface public void cancelRandom() {
            ReminderReceiver.cancelAll(MainActivity.this);
            getSharedPreferences("sandev", MODE_PRIVATE).edit().putBoolean("notif_enabled", false).apply();
            runOnUiThread(() -> Toast.makeText(MainActivity.this, "Notifikasi dimatikan", Toast.LENGTH_SHORT).show());
        }
        @JavascriptInterface public void setEnabled(boolean enabled) { getSharedPreferences("sandev", MODE_PRIVATE).edit().putBoolean("notif_enabled", enabled).apply(); if (enabled) scheduleNext(); }
    }

    private void scheduleNext() {
        getSharedPreferences("sandev", MODE_PRIVATE).edit().putBoolean("notif_enabled", true).apply();
        ReminderReceiver.cancelAll(this);
        ReminderReceiver.scheduleAll(this);
    }
}
