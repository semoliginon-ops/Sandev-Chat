package com.sandev.chat;

import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import java.util.Calendar;
import java.util.Random;

public class ReminderReceiver extends BroadcastReceiver {
    private static final int REQUEST_BASE = 7100;
    private static final String[] MESSAGES = {
        "Hai, lagi apa? Aku mampir sebentar buat nemenin kamu ❤️",
        "Jangan lupa istirahat sebentar ya. Kamu juga perlu dijaga.",
        "Semoga harimu lancar. Kalau mau cerita, aku siap menemani.",
        "Psst... ini pengingat kecil kalau kamu pantas dapat hari yang baik 😊",
        "Sudah minum air? Yuk, ambil jeda sebentar."
    };

    public static void scheduleAll(Context context) {
        android.content.SharedPreferences prefs = context.getSharedPreferences("sandev", Context.MODE_PRIVATE);
        if (!prefs.getBoolean("notif_enabled", false)) return;
        int count = Math.max(1, Math.min(5, prefs.getInt("notif_count", 2)));
        for (int i = 0; i < count; i++) scheduleOne(context, REQUEST_BASE + i, false);
    }

    public static void cancelAll(Context context) {
        AlarmManager am = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (am == null) return;
        for (int i = 0; i < 5; i++) {
            Intent intent = new Intent(context, ReminderReceiver.class).putExtra("request_id", REQUEST_BASE + i);
            PendingIntent pi = PendingIntent.getBroadcast(context, REQUEST_BASE + i, intent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
            am.cancel(pi);
        }
    }

    private static void scheduleOne(Context context, int requestId, boolean tomorrow) {
        android.content.SharedPreferences prefs = context.getSharedPreferences("sandev", Context.MODE_PRIVATE);
        if (!prefs.getBoolean("notif_enabled", false)) return;
        int min = Math.max(0, Math.min(23, prefs.getInt("notif_min", 8)));
        int max = Math.max(min + 1, Math.min(24, prefs.getInt("notif_max", 22)));
        Calendar c = Calendar.getInstance();
        Random random = new Random(System.nanoTime() ^ requestId ^ System.currentTimeMillis());
        c.set(Calendar.HOUR_OF_DAY, min + random.nextInt(Math.max(1, max - min)));
        c.set(Calendar.MINUTE, random.nextInt(60));
        c.set(Calendar.SECOND, 0);
        c.set(Calendar.MILLISECOND, 0);
        long minimumTime = System.currentTimeMillis() + 60_000L;
        if (tomorrow || c.getTimeInMillis() < minimumTime) c.add(Calendar.DAY_OF_YEAR, 1);
        Intent intent = new Intent(context, ReminderReceiver.class).putExtra("request_id", requestId);
        PendingIntent pi = PendingIntent.getBroadcast(context, requestId, intent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        AlarmManager am = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (am != null) {
            if (Build.VERSION.SDK_INT >= 23) am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, c.getTimeInMillis(), pi);
            else am.set(AlarmManager.RTC_WAKEUP, c.getTimeInMillis(), pi);
        }
    }

    @Override public void onReceive(Context context, Intent intent) {
        String action = intent == null ? null : intent.getAction();
        if (Intent.ACTION_BOOT_COMPLETED.equals(action)) {
            scheduleAll(context);
            return;
        }
        android.content.SharedPreferences prefs = context.getSharedPreferences("sandev", Context.MODE_PRIVATE);
        if (!prefs.getBoolean("notif_enabled", false)) return;
        String title = prefs.getString("notif_title", "Sandev Chat");
        String body = prefs.getString("notif_body", "");
        if (body.trim().isEmpty()) body = MESSAGES[new Random().nextInt(MESSAGES.length)];
        Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(context, "sandev_companion") : new Notification.Builder(context);
        b.setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle(title).setContentText(body).setStyle(new Notification.BigTextStyle().bigText(body)).setAutoCancel(true);
        NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm != null) nm.notify((int) (System.currentTimeMillis() & 0x7fffffff), b.build());
        int requestId = intent == null ? REQUEST_BASE : intent.getIntExtra("request_id", REQUEST_BASE);
        scheduleOne(context, requestId, true);
    }
}
