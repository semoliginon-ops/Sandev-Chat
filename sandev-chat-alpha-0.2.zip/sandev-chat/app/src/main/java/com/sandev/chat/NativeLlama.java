package com.sandev.chat;

/** JNI bridge to the llama.cpp runtime. Native calls run on worker threads. */
public final class NativeLlama {
    static {
        System.loadLibrary("sandevllama");
    }
    private NativeLlama() {}
    public static native boolean loadModel(String path, int contextLength, int threads);
    public static native boolean isLoaded();
    public static native String generate(String prompt, int maxTokens, float temperature, float topP, float repeatPenalty);
    public static native void unload();
}
