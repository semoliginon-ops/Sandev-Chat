#include <jni.h>
#include <android/log.h>
#include <string>
#include <vector>
#include <mutex>
#include <algorithm>
#include <cstring>
#include <ctime>
#include "llama.h"

#define LOG_TAG "SandevLlama"
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

static std::mutex g_mutex;
static llama_model *g_model = nullptr;
static llama_context *g_ctx = nullptr;
static llama_sampler *g_sampler = nullptr;
static int g_ctx_size = 1024;

static void unload_locked() {
    if (g_sampler) { llama_sampler_free(g_sampler); g_sampler = nullptr; }
    if (g_ctx) { llama_free(g_ctx); g_ctx = nullptr; }
    if (g_model) { llama_free_model(g_model); g_model = nullptr; }
}
static std::string from_jstring(JNIEnv *env, jstring s) {
    if (!s) return {};
    const char *p = env->GetStringUTFChars(s, nullptr);
    std::string out = p ? p : "";
    if (p) env->ReleaseStringUTFChars(s, p);
    return out;
}
extern "C" JNIEXPORT jboolean JNICALL
Java_com_sandev_chat_NativeLlama_loadModel(JNIEnv *env, jclass, jstring jpath, jint contextLength, jint threads) {
    std::lock_guard<std::mutex> lock(g_mutex);
    unload_locked();
    std::string path = from_jstring(env, jpath);
    llama_backend_init();
    llama_model_params mp = llama_model_default_params();
    mp.use_mmap = true;
    g_model = llama_load_model_from_file(path.c_str(), mp);
    if (!g_model) { LOGE("llama_load_model_from_file failed"); return JNI_FALSE; }
    llama_context_params cp = llama_context_default_params();
    g_ctx_size = std::max(256, std::min(4096, (int)contextLength));
    cp.n_ctx = (uint32_t)g_ctx_size;
    cp.n_batch = (uint32_t)std::min(512, g_ctx_size);
    cp.n_threads = std::max(1, std::min(4, (int)threads));
    cp.n_threads_batch = cp.n_threads;
    g_ctx = llama_new_context_with_model(g_model, cp);
    if (!g_ctx) { LOGE("llama_new_context_with_model failed"); unload_locked(); return JNI_FALSE; }
    return JNI_TRUE;
}
extern "C" JNIEXPORT jboolean JNICALL
Java_com_sandev_chat_NativeLlama_isLoaded(JNIEnv *, jclass) {
    std::lock_guard<std::mutex> lock(g_mutex);
    return (g_model && g_ctx) ? JNI_TRUE : JNI_FALSE;
}
extern "C" JNIEXPORT void JNICALL
Java_com_sandev_chat_NativeLlama_unload(JNIEnv *, jclass) {
    std::lock_guard<std::mutex> lock(g_mutex); unload_locked();
}
extern "C" JNIEXPORT jstring JNICALL
Java_com_sandev_chat_NativeLlama_generate(JNIEnv *env, jclass, jstring jprompt, jint maxTokens, jfloat temperature, jfloat topP, jfloat repeatPenalty) {
    std::lock_guard<std::mutex> lock(g_mutex);
    if (!g_model || !g_ctx) return env->NewStringUTF("Model belum dimuat.");
    std::string prompt = from_jstring(env, jprompt);
    const llama_vocab *vocab = llama_model_get_vocab(g_model);
    std::vector<llama_token> tokens(std::max<size_t>(prompt.size() + 32, 256));
    int n_prompt = llama_tokenize(vocab, prompt.c_str(), (int32_t)prompt.size(), tokens.data(), (int32_t)tokens.size(), true, true);
    if (n_prompt < 0) {
        tokens.resize((size_t)(-n_prompt));
        n_prompt = llama_tokenize(vocab, prompt.c_str(), (int32_t)prompt.size(), tokens.data(), (int32_t)tokens.size(), true, true);
    }
    if (n_prompt <= 0 || n_prompt >= g_ctx_size) return env->NewStringUTF("Prompt terlalu panjang untuk context model. Kurangi riwayat chat atau context.");
    tokens.resize((size_t)n_prompt);
    llama_kv_cache_clear(g_ctx);
    llama_batch batch = llama_batch_init(n_prompt, 0, 1);
    batch.n_tokens = n_prompt;
    for (int i = 0; i < n_prompt; ++i) {
        batch.token[i] = tokens[(size_t)i];
        batch.pos[i] = i;
        batch.n_seq_id[i] = 1;
        batch.seq_id[i][0] = 0;
        batch.logits[i] = (i == n_prompt - 1);
    }
    int decode_result = llama_decode(g_ctx, batch);
    llama_batch_free(batch);
    if (decode_result != 0) return env->NewStringUTF("Gagal memproses prompt. Coba context yang lebih kecil.");

    llama_sampler_chain_params sp = llama_sampler_chain_default_params();
    g_sampler = llama_sampler_chain_init(sp);
    llama_sampler_chain_add(g_sampler, llama_sampler_init_penalties(64, std::max(1.0f, repeatPenalty), 0.0f, 0.0f));
    if (temperature > 0.001f) llama_sampler_chain_add(g_sampler, llama_sampler_init_temp(std::min(2.0f, temperature)));
    llama_sampler_chain_add(g_sampler, llama_sampler_init_top_p(std::max(0.05f, std::min(1.0f, topP)), 1));
    llama_sampler_chain_add(g_sampler, llama_sampler_init_dist((uint32_t)time(nullptr)));

    std::string output;
    int n_past = n_prompt;
    int limit = std::max(1, std::min((int)maxTokens, g_ctx_size - n_prompt));
    std::vector<char> piece(8192);
    for (int i = 0; i < limit; ++i) {
        llama_token token = llama_sampler_sample(g_sampler, g_ctx, -1);
        if (llama_vocab_is_eog(vocab, token)) break;
        int n_piece = llama_token_to_piece(vocab, token, piece.data(), (int)piece.size(), 0, true);
        if (n_piece > 0) output.append(piece.data(), (size_t)n_piece);
        llama_batch next = llama_batch_init(1, 0, 1);
        next.n_tokens = 1;
        next.token[0] = token;
        next.pos[0] = n_past;
        next.n_seq_id[0] = 1;
        next.seq_id[0][0] = 0;
        next.logits[0] = true;
        int rc = llama_decode(g_ctx, next);
        llama_batch_free(next);
        if (rc != 0) break;
        ++n_past;
    }
    llama_sampler_free(g_sampler); g_sampler = nullptr;
    if (output.empty()) output = "Model tidak menghasilkan teks. Coba prompt lain atau periksa template chat.";
    return env->NewStringUTF(output.c_str());
}
